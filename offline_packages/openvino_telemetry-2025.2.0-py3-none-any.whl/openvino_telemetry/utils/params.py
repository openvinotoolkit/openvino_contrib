# Copyright (C) 2018-2025 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

telemetry_params = {
    "api_key": "zbEMioDXSE-MUHHPLRIi0A"
}
